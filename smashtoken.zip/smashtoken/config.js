// telegram token
var token = '860721842:AAHKLaGdIFC9OrNlavVSIRPeAxk4QPejcFk'
// firebase config
var config = {
    apiKey: "AIzaSyDFs9SOhac-SZ6mYPp-9T0J9VJLnCwWdnc",
    authDomain: "https://smashtoken-airdrop.firebaseapp.com/",
    databaseURL: "https://smashtoken-airdrop.firebaseio.com/",
    projectId: "smashtoken-airdrop",
    storageBucket: "gs://smashtoken-airdrop.appspot.com/",
};

exports.token = token;
exports.firebase_config = config;
